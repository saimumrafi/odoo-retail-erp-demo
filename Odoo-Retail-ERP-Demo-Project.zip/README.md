# 🧾 Odoo Retail Inventory & Sales Management – Demo Project

This is a functional Odoo ERP demo project implemented as a **Business Analyst** case study. The project simulates how a retail electronics business digitizes its core workflows using **Odoo Community Edition**.

...

## 📁 Project Artifacts

- 📄 [BRD – Business Requirements](documents/BRD.md)
- ✅ [Test Cases](documents/TestCases.md)
- 📘 [User Manual](documents/UserManual.md)
- 🖼️ [Workflow Diagram](documents/Workflow-Diagram.png)
...
