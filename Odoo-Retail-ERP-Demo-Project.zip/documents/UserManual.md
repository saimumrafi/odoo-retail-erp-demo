# 📘 User Manual – Odoo Retail ERP

### 🔹 How to Add a Product
1. Go to Inventory → Products → Create
2. Enter product name, category, cost, and quantity
3. Save

...
