# ✅ Test Cases – Odoo Retail Project

## Module: Sales

| TC ID | Test Case | Expected Result | Status |
|-------|-----------|------------------|--------|
| TC-001 | Create Sales Order | Order status should be "Quotation Sent" | ✅ |
...
